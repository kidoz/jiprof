package test.verboseclass;

public class Main {
	public static void main(String[] args) {
		String[] sentence = {"Profiling", "Java", "is", "fun"};
		
		for (String word : sentence) {
			System.out.println(word);
		}
	}
}
