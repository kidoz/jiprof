#!/bin/sh
$JAVA_HOME/bin/java -jar client.jar finish $1 $2
